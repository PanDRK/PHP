<html>
    <head>
        <marquee>
        <font color="#DB46BB">
          <h1>VENTA DE VENTILADORES</h1>
        </font>
        </marquee>
    </head>

    <body bgcolor="#F0CDCC">
        <form action="ticket.php">
            <table>
                <tr>
                   <h3>Ventilador de torre:</h3>
                   <br> Se distingue de los ventiladores de aspa que, debido al diámetro de sus aspas,<br> 
                    pueden ocupar más espacio.Se integra en el ambiente del hogar con elegancia y discreción
                    <b> <br> Precio:1859 </b>
                   <center ><img src="torre.jpg"weight="400" height="300"> </center>
                </tr>
                <tr>
                    <h3>Ventilador de techo: </h3>
                    <br> Sus aspas están diseñadas para que el ventilador no oscile ni haga ruido<br> 
                    Es ideal si no quiere ocupar espacio en su piso.
                    <b> <br> Precio:1719 </b>
                    <center> <img src="techo.jpeg"weight="400" height="300"></center>
                 </tr>
                 <tr>
                    <h3>Ventilador de piso: </h3>
                    <br> No posee nungún tipo de soporte o pedestal. Tiene una gran potencia y capacidad. <br>  
                    Ideales para secar el piso luego de limpiarlo, ya que impulsan el aire a gran velocidad
                    <b> <br> Precio:699 </b>
                    <center><img src="piso.jpeg"weight="400" height="300"></center>
          
                 </tr>
                 <tr>
                    <h3>Ventilador de pedestal:</h3>
                    <br> Gracias a su peso ligero es fácil de transportar y armar <br> 
                    Cuenta con una base que sujeta la estructura para expulsar así el aire frío a mayor altura. 
                    Son de gran velocidad además de ser reclinables
                    <b> <br> Precio:1329 </b>
                    <center ><img src="pedestal.jpeg"weight="400" height="300"></center>
                 </tr>
                 <tr>
                    <h3>Ventilador portátil: </h3>
                    <br> Ventilador portátil que es facil y manejable para traer en cualquier lugar <br> 
                    es pequeño y se ajusta a tus comodidades
                    <b> <br> Precio:150 </b>
                    <center><img src="portatil.jpeg"weight="400" height="300"></center>
                 </tr>
            </table>
            <center>
            <button>Seleccionar productos</button>
            </center>
        </form>
    </body>
</html>