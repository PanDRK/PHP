<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="recursos/css/style.css">
    <link rel="icon" href="recursos/img/header/heart.png">
    <title>Optica blas - Pagina de incio</title>
</head>

<body>
    <header class="hed">
        <img class="icon" src="recursos/img/header/log_neg.png" alt="Logo">
        <h1 class="titi" style="padding-left: 50px;">La mejor tienda de lentes para todas las edades</h1>
    </header>

    <main>
        <form method="POST" action="compra.php">
            <div class="elem">
                <div class="image-container">
                    <img src="recursos/img/gal/cans.png" alt="loq de 16'">
                    <div class="overlay">
                        <div class="text">
                            <h4>Lentes de lectura</h4>
                            <p>Disfruta de una lectura cómoda con nuestros lentes de lectura</p>
                            <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer, 
                                ya que estan ajustados para una lectura a conta distancia por lo que no va 
                                a tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $120 MXN.</p>
                        </div>
                        <br><br>
                        <div class="btn">
                            <button class="ui-btn">
                                <span>
                                    Comprar
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="image-container">
                    <img src="recursos/img/gal/compi.png" alt="Rog zerphirus g16">
                    <div class="overlay">
                        <div class="text">
                            <h4>Lentes para Computadora</h4>
                            <p>Disfruta de un uso comodo de la computadoracon nuestros lentes especiales para pantallas</p>
                            <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer,
                                y trabar con patallas ya que estan ajustados para un uso continuo de la computadora y no 
                                tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $500 MXN.</p>
                        </div>
                        <br><br>
                        <div class="btn">
                            <button class="ui-btn">
                                <span>
                                    Comprar
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="image-container">
                    <img src="recursos/img/gal/contc.png" alt="ThinkBoock">
                    <div class="overlay">
                        <div class="text">
                            <h4>Lentes de contacto</h4>
                            <p>Disfruta de una vida más cómoda con nuestros lentes de contacto</p>
                            <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de realizar 
                                actividades ya que por su versatibilidad y uso en un dia a dia es mas comodo, ya
                                que estos lentes estan especificamente hechos para cada persona no puedes
                                tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $1500 MXN.</p>
                        </div>
                        <br><br>
                        <div class="btn">
                            <button class="ui-btn">
                                <span>
                                    Comprar
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="image-container">
                    <img src="recursos/img/gal/lent.avif" alt="ThinkPad p16 gen1">
                    <div class="overlay">
                        <div class="text">
                            <h4>Anteojos</h4>
                            <p>Disfruta de una claridad en la mirada todas las mañanas</p>
                            <p>Con nuestros lentes podras tener una mejor experiencia a la hora de leer y
                                realizar actividades del dia a dia ya que estan ajustados para cada persona
                                por lo que no va a tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $120 MXN.</p>
                        </div>
                        <br><br>
                        <div class="btn">
                            <button class="ui-btn">
                                <span>
                                    Comprar
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="image-container">
                    <img src="recursos/img/gal/sol.webp" alt="Rog Strix g16">
                    <div class="overlay">
                        <div class="text">
                            <h4>Lentes de sol</h4>
                            <p>Disfruta de una vicion perfecta y estilo unico con nuestros lentes de sol</p>
                            <p>Estos lentes se caracterizan por dar una sensacion de comodidad y buena images, 
                                ya que se ajustan a los gustos de cada persona por lo que no vas a tener problemas con
                                la imagen y sobre todo con los ambientes sobre iluminados.
                            </p>
                            <p><strong>Precio:</strong> $1800 MXN.</p>
                        </div>
                        <br><br>
                        <div class="btn">
                            <button class="ui-btn">
                                <span>
                                    Comprar
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>

</body>

</html>