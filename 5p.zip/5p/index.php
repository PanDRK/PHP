<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="recursos/css/style.css">
    <title></title>
</head>

<body>

    <header class="hed">
        <img class="icon" src="recursos/img/header/heart.png" alt="icono de la pagina"> <br>
        <h1 class="titi">CyberHeart</h1>
    </header>
    <h1>La mejor tienda de computadoras de Querétaro</h1>

    <div class="elem">

    </div>

    <main>



    </main>
</body>

</html>