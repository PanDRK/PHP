<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="recursos/css/styles.css">
    <link rel="icon" href="recursos/img/header/log.png">
    <title>Optica Blas - Seleccion y ticket</title>
</head>

<body>
    <header class="hed">
        <img class="icon" src="recursos/img/header/log_neg.png" alt="Logo">
        <h1 class="titi" style="padding-left: 50px;">La mejor tienda de lentes para todas las edades</h1>
    </header>

    <div class="select">
        <?php

        $productos = array(
            array("nombre" => "Lentes de Lectura", "caracteristicas" => "<p>Disfruta de una lectura cómoda con nuestros lentes de lectura</p>
                        <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer, 
                            ya que estan ajustados para una lectura a conta distancia por lo que no va 
                            a tener problemas con la vista.
                        </p>", "precio" => 120, "imagen" => "recursos/img/gal/cans.png"),
            array("nombre" => "Lentes para computadora", "caracteristicas" => "
                            <p>Disfruta de un uso comodo de la computadoracon nuestros lentes especiales para pantallas</p>
                            <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer,
                                y trabar con patallas ya que estan ajustados para un uso continuo de la computadora y no 
                                tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $500 MXN.</p>", "precio" => 500, "imagen" => "recursos/img/gal/compi.png"),
            array("nombre" => "Lentes de contacto", "caracteristicas" => "<p>Disfruta de una vida más cómoda con nuestros lentes de contacto</p>
                        <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de realizar 
                            actividades ya que por su versatibilidad y uso en un dia a dia es mas comodo, ya
                            que estos lentes estan especificamente hechos para cada persona no puedes
                            tener problemas con la vista.
                        </p>", "precio" => 1500, "imagen" => "recursos/img/gal/contc.png"),
            array("nombre" => "Anteojos", "caracteristicas" => "<p>Disfruta de una claridad en la mirada todas las mañanas</p>
                        <p>Con nuestros lentes podras tener una mejor experiencia a la hora de leer y
                            realizar actividades del dia a dia ya que estan ajustados para cada persona
                            por lo que no va a tener problemas con la vista.
                        </p>", "precio" => 2500, "imagen" => "recursos/img/gal/lent.avif"),
            array("nombre" => "Lentes de sol", "caracteristicas" => "<p>Disfruta de una vicion perfecta y estilo unico con nuestros lentes de sol</p>
                        <p>Estos lentes se caracterizan por dar una sensacion de comodidad y buena images, 
                            ya que se ajustan a los gustos de cada persona por lo que no vas a tener problemas con
                            la imagen y sobre todo con los ambientes sobre iluminados.
                        </p>", "precio" => 1800, "imagen" => "recursos/img/gal/sol.webp")
        );

        echo "<h1>Seleccione la cantidad de productos que desea comprar:</h1>";
        echo "<form method='post' action='ticket.php'>";
        echo "<br><br><br><br><br><br>
                <table width='900px'>";
        echo "<tr><th width='300px' align='center'>Nombre</th>
                <th width='400px'>Características</th>
                <th width='200px' align='center'>Precio</th>
                <th align='center'>Cantidad</th>
                <th align='center'>Imagen</th></tr>";
        foreach ($productos as $key => $producto) {
            echo "<tr>";
            echo "<td>" . $producto['nombre'] . "</td>";
            echo "<td>" . $producto['caracteristicas'] . "</td>";
            echo "<td width='100px' align='center'>$" . $producto['precio'] . "</td>";
            echo "<td><input type='number' name='cantidad$key' min='0' value='0' class='input'></td>";
            echo "<td width='100px' align='center'><img src='" . $producto['imagen'] . "' width='50px'></td>";
            echo '</tr>';
        }
        echo '<tr><td colspan="5" align="center" height="70px">
            <form method="POST" action="ticket.php">
            <br><br>
                <button class="cta">
                    <span class="hover-underline-animation"> Shop now </span>
                    <svg
                    id="arrow-horizontal"
                    xmlns="http://www.w3.org/2000/svg"
                    width="30"
                    height="10"
                    viewBox="0 0 46 16"
                    >
                    <path
                        id="Path_10"
                        data-name="Path 10"
                        d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z"
                        transform="translate(30)"
                    ></path>
                    </svg>
                </button></form>
                <br><br><br><br><br><form action="index.php">
            <button class="cta">
            <span class="hover-underline-animation"> Regresar </span>
            <svg
            id="arrow-horizontal"
            xmlns="http://www.w3.org/2000/svg"
            width="30"
            height="10"
            viewBox="0 0 46 16"
            >
            <path
                id="Path_10"
                data-name="Path 10"
                d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z"
                transform="translate(30)"
            ></path>
            </svg>
        </button>
                </td></tr>';
        ?>
    </div>

</body>

</html>