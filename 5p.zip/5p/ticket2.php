<?php

$productos = array(
    array("nombre" => "Ventilador de torre", "caracteristicas" => "Se distingue de los ventiladores de aspa que, debido al diámetro de sus aspas,<br> 
                    pueden ocupar más espacio.Se integra en el ambiente del hogar con elegancia y discreción", "precio" => 1859, "imagen" => "torre.jpg"),
    array("nombre" => "Ventilador de techo ", "caracteristicas" => "Sus aspas están diseñadas para que el ventilador no oscile ni haga ruido<br> 
    Es ideal si no quiere ocupar espacio en su piso.", "precio" => 1719, "imagen" => "techo.jpeg"),
    array("nombre" => "Ventlador de piso ", "caracteristicas" => "No posee nungún tipo de soporte o pedestal. Tiene una gran potencia y capacidad. <br>  
    Ideales para secar el piso luego de limpiarlo, ya que impulsan el aire a gran velocidad", "precio" => 699, "imagen" => "piso.jpeg"),
    array("nombre" => "Ventilador de pedestañ ", "caracteristicas" => "Gracias a su peso ligero es fácil de transportar y armar <br> 
    Cuenta con una base que sujeta la estructura para expulsar así el aire frío a mayor altura. <br> 
    Son de gran velocidad además de ser reclinables", "precio" => 1359, "imagen" => "pedestal.jpeg"),
    array("nombre" => "Ventlador portatil", "caracteristicas" => "Ventilador portátil que es facil y manejable para traer en cualquier lugar <br> 
    es pequeño y se ajusta a tus comodidades", "precio" => 150, "imagen" => "portatil.jpeg")
);


$total = 0;


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    echo "<h1>Ticket de Compra</h1>";
    echo"<h2> VentiFresh </h2>";
    echo"<h3> 21 de Mayo de 2024</h3>";
    echo "<table border='1'>";
    echo "<tr><th>Nombre</th><th>Características</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th>Imagen</th></tr>";
    foreach ($productos as $key => $producto) {
        
        $cantidad = $_POST["cantidad$key"];
        if ($cantidad > 0) {
            
            $subtotal = $cantidad * $producto['precio'];
       
            echo "<tr>";
            echo "<td>" . $producto['nombre'] . "</td>";
            echo "<td>" . $producto['caracteristicas'] . "</td>";
            echo "<td>$" . $producto['precio'] . "</td>";
            echo "<td>$cantidad</td>";
            echo "<td>$" . number_format($subtotal, 2) . "</td>";
            echo "<td><img src='" . $producto['imagen'] . "' width='50' height='50'></td>";
            echo "</tr>";
           
            $total += $subtotal;
        }
    }


    if ($total <= 500) {
        echo "Esa cantidad no aplica descuento";
    } 
    if ($total >= 501 && $total<=1000) {
        $totalconDescuento = $total * 5/100;
        $final=$total-$totalconDescuento;
        echo"<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
        echo"<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
        echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
    }
    if ($total >= 1001 && $total<=3000) {
        $totalconDescuento = $total * 8/100;
        $final=$total-$totalconDescuento;
        echo"<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
        echo"<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
        echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" .($final) . "</b></td></tr>";
    }

    if ($total >= 3001 && $total<=5000) {
        $totalconDescuento = $total * 9/100;
        $final=$total-$totalconDescuento;
        echo"<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
        echo"<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
        echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
    }
    if ($total >= 5001) {

        $totalconDescuento = $total * 10/100;
        $final=$total-$totalconDescuento;
        echo"<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
        echo"<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
        echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
    }
   
   
    echo "</table>";
} else {

    echo "<h1>Seleccione la cantidad de productos que desea comprar:</h1>";
    echo "<form method='post' action='" . $_SERVER['PHP_SELF'] . "'>";
    echo "<table border='1'>";
    echo "<tr><th>Nombre</th><th>Características</th><th>Precio</th><th>Cantidad</th><th>Imagen</th></tr>";
    foreach ($productos as $key => $producto) {
        echo "<tr>";
        echo "<td>" . $producto['nombre'] . "</td>";
        echo "<td>" . $producto['caracteristicas'] . "</td>";
        echo "<td>$" . $producto['precio'] . "</td>";
        echo "<td><input type='number' name='cantidad$key' min='0' value='0'></td>";
        echo "<td><img src='" . $producto['imagen'] . "' width='50' height='50'></td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<br><input type='submit' value='Generar Ticket'>";
    echo "</form>";
}


?>



