<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="recursos/css/styles.css">
    <link rel="icon" href="recursos/img/header/log.png">
    <title>Optica Blas - Seleccion y ticket</title>
</head>

<body>
    <header class="hed">
        <img class="icon" src="recursos/img/header/log_neg.png" alt="Logo">
        <h1 class="titi" style="padding-left: 50px;">La mejor tienda de lentes para todas las edades</h1>
    </header>

    <div class="select1">
        <?php

        $productos = array(
            array("nombre" => "Lentes de Lectura", "caracteristicas" => "<p>Disfruta de una lectura cómoda con nuestros lentes de lectura</p>
                        <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer, 
                            ya que estan ajustados para una lectura a conta distancia por lo que no va 
                            a tener problemas con la vista.
                        </p>", "precio" => 120, "imagen" => "recursos/img/gal/cans.png"),
            array("nombre" => "Lentes para computadora", "caracteristicas" => "
                            <p>Disfruta de un uso comodo de la computadoracon nuestros lentes especiales para pantallas</p>
                            <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de leer,
                                y trabar con patallas ya que estan ajustados para un uso continuo de la computadora y no 
                                tener problemas con la vista.
                            </p>
                            <p><strong>Precio:</strong> $500 MXN.</p>", "precio" => 500, "imagen" => "recursos/img/gal/compi.png"),
            array("nombre" => "Lentes de contacto", "caracteristicas" => "<p>Disfruta de una vida más cómoda con nuestros lentes de contacto</p>
                        <p>Estos lentes se caracterizan por dar una mejor experiencia a la hora de realizar 
                            actividades ya que por su versatibilidad y uso en un dia a dia es mas comodo, ya
                            que estos lentes estan especificamente hechos para cada persona no puedes
                            tener problemas con la vista.
                        </p>", "precio" => 1500, "imagen" => "recursos/img/gal/contc.png"),
            array("nombre" => "Anteojos", "caracteristicas" => "<p>Disfruta de una claridad en la mirada todas las mañanas</p>
                        <p>Con nuestros lentes podras tener una mejor experiencia a la hora de leer y
                            realizar actividades del dia a dia ya que estan ajustados para cada persona
                            por lo que no va a tener problemas con la vista.
                        </p>", "precio" => 2500, "imagen" => "recursos/img/gal/lent.avif"),
            array("nombre" => "Lentes de sol", "caracteristicas" => "<p>Disfruta de una vicion perfecta y estilo unico con nuestros lentes de sol</p>
                        <p>Estos lentes se caracterizan por dar una sensacion de comodidad y buena images, 
                            ya que se ajustan a los gustos de cada persona por lo que no vas a tener problemas con
                            la imagen y sobre todo con los ambientes sobre iluminados.
                        </p>", "precio" => 1800, "imagen" => "recursos/img/gal/sol.webp")
        );


        $total = 0;


        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            echo "<h1>Ticket de Compra</h1>";
            echo "<h2> Optica Blas </h2>";
            echo "<h3> 22 de Mayo de 2024</h3>
                <br><br><br><br><br><br><br>";
            echo "<table width='900px' border='0'>";
            echo "<tr><th width='400px' align='center'>Nombre</th>
                <th width='400px'>Características</th>
                <th width='200px' align='center'>Precio</th>
                <th align='center'>Cantidad</th>
                <th width='200px' align='center'>subtotal</th></tr>";

            foreach ($productos as $key => $producto) {

                $cantidad = $_POST["cantidad$key"];
                if ($cantidad > 0) {

                    $subtotal = $cantidad * $producto['precio'];

                    echo "<tr>";
                    echo "<td align='center'> <strong>" . $producto['nombre'] . "</strong></td>";
                    echo "<td>" . $producto['caracteristicas'] . "</td>";
                    echo "<td align='center'>$" . $producto['precio'] . "</td>";
                    echo "<td align='center'>$cantidad</td>";
                    echo "<td align='center'>$" . number_format($subtotal, 2) . "</td>";
                    echo "</tr>";

                    $total += $subtotal;
                } else{
                    echo "<tr>";
                    echo "<td>-</td>";
                    echo "<td>----------</td>";
                    echo "<td>$-</td>";
                    echo "<td>-</td>";
                    echo "<td>$ - <td>";
                    echo "</tr>";
                }
            }


            if ($total <= 500) {
                echo "Esa cantidad no aplica descuento";
            }
            if ($total >= 501 && $total <= 1000) {
                $totalconDescuento = $total * 5 / 100;
                $final = $total - $totalconDescuento;
                echo "<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
            }
            if ($total >= 1001 && $total <= 3000) {
                $totalconDescuento = $total * 8 / 100;
                $final = $total - $totalconDescuento;
                echo "<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
            }

            if ($total >= 3001 && $total <= 5000) {
                $totalconDescuento = $total * 9 / 100;
                $final = $total - $totalconDescuento;
                echo "<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
            }
            if ($total >= 5001) {

                $totalconDescuento = $total * 10 / 100;
                $final = $total - $totalconDescuento;
                echo "<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
            }
            if($total==0){

                $totalconDescuento = 0;
                $final = $total - $totalconDescuento;
                echo "<tr><td colspan='4'><b>Total sin descuento:</b></td><td><b>$" . ($total) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Descuento:</b></td><td><b>$" . ($totalconDescuento) . "</b></td></tr>";
                echo "<tr><td colspan='4'><b>Total final:</b></td><td><b>$" . ($final) . "</b></td></tr>";
            }

            echo "</table>";
        } else {
        }
        echo '<br><br><br><br><br><form action="index.php">
            <button class="cta">
            <span class="hover-underline-animation"> Regresar </span>
            <svg
            id="arrow-horizontal"
            xmlns="http://www.w3.org/2000/svg"
            width="30"
            height="10"
            viewBox="0 0 46 16"
            >
            <path
                id="Path_10"
                data-name="Path 10"
                d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z"
                transform="translate(30)"
            ></path>
            </svg>
        </button></form>';
        ?>
    </div>

</body>

</html>